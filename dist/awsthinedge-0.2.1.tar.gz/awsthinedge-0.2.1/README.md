# AWSThinEdge
Robot Framework Library for testing thinedge.io with AWS
